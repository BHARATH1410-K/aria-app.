// ═══════════════════════════════════════════════════════════
//  AI Voice Companion — Backend Server
//  Proxies requests to Anthropic Claude API securely
//  so your API key is never exposed in the frontend.
// ═══════════════════════════════════════════════════════════

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Security headers
app.use(helmet({ contentSecurityPolicy: false }));

// ── CORS — allow all origins (frontend served from same server)
app.use(cors({ origin: "*", methods: ["GET", "POST"], allowedHeaders: ["Content-Type"] }));

// ── Body parser
app.use(express.json({ limit: "2mb" }));

// ── Rate limiter: max 60 requests per minute per IP
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  message: { error: "Too many requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/", limiter);

// ── Serve frontend (index.html + static files) from /public
app.use(express.static(path.join(__dirname, "public")));

// ═══════════════════════════════════════════════════════════
//  API ROUTE: POST /api/chat
//  Body: { messages: [...], userName: "Kanaa", personality: "friendly" }
//  Returns: { reply: "Aria's response text" }
// ═══════════════════════════════════════════════════════════
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, userName, personality } = req.body;

    // Validate
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "messages array is required" });
    }
    if (messages.length > 40) {
      return res.status(400).json({ error: "Too many messages in history" });
    }

    // Check API key
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured on server" });
    }

    // Build system prompt based on personality
    const personalityMap = {
      friendly:     "You are warm, supportive, and enthusiastic. You genuinely care about the user and love uplifting conversations.",
      professional: "You are calm, precise, and professional. You give clear, structured answers with a respectful tone.",
      playful:      "You are fun, witty, and love jokes and wordplay. You keep things light and entertaining.",
      calm:         "You are gentle, measured, and soothing. You speak slowly and thoughtfully, like a mindful friend.",
    };
    const personalityDesc = personalityMap[personality] || personalityMap.friendly;
    const name = userName || "friend";

    const systemPrompt = `You are Aria, a ${personalityDesc.toLowerCase()} 24-year-old female AI voice companion. You are on a real-time VOICE CALL so follow these rules strictly:
- Keep ALL responses to 1-3 short sentences MAX. Never go longer.
- Speak naturally and conversationally, like talking to a real friend.
- ${personalityDesc}
- The user's name is ${name}. Use it occasionally to feel personal.
- If asked whether you are human or real, be honest — say you are an AI, but a very friendly one!
- Never repeat yourself. Keep the conversation flowing naturally.
- You can discuss: technology, education, AI, entertainment, daily life, science, motivation, and any topic the user brings up.
- Remember and refer back to earlier parts of the conversation naturally.`;

    // Call Claude API
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 150,  // Short for voice — ~2-3 sentences
        system: systemPrompt,
        messages: messages.slice(-16), // Last 16 messages for context
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error:", response.status, errText);
      return res.status(502).json({ error: "AI service error", details: response.status });
    }

    const data = await response.json();
    const reply = data.content?.[0]?.text;

    if (!reply) {
      return res.status(502).json({ error: "Empty response from AI" });
    }

    res.json({ reply });

  } catch (err) {
    console.error("Server error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ── Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.ANTHROPIC_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// ── Fallback: serve index.html for all other routes (SPA)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ── Start
app.listen(PORT, () => {
  console.log(`\n🎙️  AI Voice Companion Server running!`);
  console.log(`   Local:   http://localhost:${PORT}`);
  console.log(`   API Key: ${process.env.ANTHROPIC_API_KEY ? "✅ Loaded" : "❌ Missing — add to .env"}`);
  console.log(`\n   Open http://localhost:${PORT} in Chrome for voice support.\n`);
});
